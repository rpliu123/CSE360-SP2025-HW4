package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import databasePart1.DatabaseHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * StaffRolePage class represents the user interface for the staff user.
 * This page displays staff monitoring functions.
 */
public class StaffRolePage {

    private User user;
    private DatabaseHelper databaseHelper;
    
    public StaffRolePage(User user, DatabaseHelper databaseHelper) {
        this.user = user;
        this.databaseHelper = databaseHelper;
    }
    
    public void show(Stage primaryStage) {
        BorderPane mainLayout = new BorderPane();
        mainLayout.setPadding(new Insets(20));
        
        // Title area
        VBox titleBox = new VBox(10);
        titleBox.setAlignment(Pos.CENTER);
        Label titleLabel = new Label("Staff Monitoring System");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        Label subtitleLabel = new Label("Monitor questions, feedback, and user interactions");
        subtitleLabel.setStyle("-fx-font-size: 14px;");
        titleBox.getChildren().addAll(titleLabel, subtitleLabel);
        
        // Function buttons
        VBox functionButtons = new VBox(15);
        functionButtons.setAlignment(Pos.CENTER);
        functionButtons.setPadding(new Insets(20, 0, 20, 0));
        
        // Create buttons for each staff function
        Button viewQuestionsButton = new Button("View Questions");
        viewQuestionsButton.setPrefWidth(200);
        viewQuestionsButton.setOnAction(e -> showUserStory("View all questions submitted by students across multiple courses so I can monitor the overall quality of student inquiries."));
        
        Button viewFeedbackButton = new Button("Access Feedback");
        viewFeedbackButton.setPrefWidth(200);
        viewFeedbackButton.setOnAction(e -> showUserStory("Access private feedback given by students about courses and instructors so I can identify patterns of concerns."));
        
        Button viewInteractionsButton = new Button("View Interactions");
        viewInteractionsButton.setPrefWidth(200);
        viewInteractionsButton.setOnAction(e -> showUserStory("View interaction histories between specific students and instructors so I can understand the context of any reported issues."));
        
        Button sendNotificationsButton = new Button("Send Notifications");
        sendNotificationsButton.setPrefWidth(200);
        sendNotificationsButton.setOnAction(e -> showUserStory("Send private notifications to instructors about potential issues in their courses so they can address them proactively."));
        
        Button configureAlertsButton = new Button("Configure Alerts");
        configureAlertsButton.setPrefWidth(200);
        configureAlertsButton.setOnAction(e -> showUserStory("Set up customizable alerts for potential red flags so I can be notified automatically."));
        
        Button dashboardButton = new Button("View All User Stories");
        dashboardButton.setPrefWidth(200);
        dashboardButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        dashboardButton.setOnAction(e -> showAllUserStories());
        
        functionButtons.getChildren().addAll(
            viewQuestionsButton, 
            viewFeedbackButton, 
            viewInteractionsButton, 
            sendNotificationsButton, 
            configureAlertsButton,
            dashboardButton
        );
        
        // Back button to return to Admin page
        Button backButton = new Button("Back to Admin Page");
        backButton.setOnAction(e -> {
            new AdminHomePage(user, databaseHelper).show(primaryStage);
        });
        
        // Add components to the layout
        mainLayout.setTop(titleBox);
        mainLayout.setCenter(functionButtons);
        mainLayout.setBottom(backButton);
        BorderPane.setAlignment(backButton, Pos.CENTER);
        BorderPane.setMargin(backButton, new Insets(20, 0, 0, 0));
        
        Scene staffScene = new Scene(mainLayout, 800, 600);
        primaryStage.setScene(staffScene);
        primaryStage.setTitle("Staff Role Page");
    }
    
    private void showUserStory(String userStory) {
        Stage dialog = new Stage();
        
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        
        Label titleLabel = new Label("User Story");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        
        TextArea storyArea = new TextArea(userStory);
        storyArea.setWrapText(true);
        storyArea.setEditable(false);
        storyArea.setPrefHeight(150);
        
        Label implementationLabel = new Label("Data");
        implementationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        
        TextArea dataArea = new TextArea(generateSampleData(userStory));
        dataArea.setWrapText(true);
        dataArea.setEditable(false);
        dataArea.setPrefHeight(200);
        
        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> dialog.close());
        
        layout.getChildren().addAll(titleLabel, storyArea, implementationLabel, dataArea, closeButton);
        
        Scene dialogScene = new Scene(layout, 600, 500);
        dialog.setScene(dialogScene);
        dialog.setTitle("User Story Details");
        dialog.show();
    }
    
    private String generateSampleData(String userStory) {
        if (userStory.contains("View all questions")) {
            return "STUDENT QUESTIONS:\n\n" +
                   "1. CS101 - Student123: \"How do I compile Java code from the command line?\"\n" +
                   "   Posted: April 10, 2025, Not Flagged\n\n" +
                   "2. CS101 - Student456: \"What's the difference between abstract classes and interfaces?\"\n" +
                   "   Posted: April 8, 2025, Not Flagged\n\n" +
                   "3. MATH202 - Student789: \"How do I solve this differential equation: dy/dx = 2xy + 3?\"\n" +
                   "   Posted: April 9, 2025, Not Flagged\n\n" +
                   "4. PHYS101 - Student123: \"Can someone explain Newton's third law with an example?\"\n" +
                   "   Posted: April 10, 2025, Flagged for follow-up\n\n" +
                   "5. ENG201 - Student456: \"Need help analyzing this passage from Shakespeare\"\n" +
                   "   Posted: April 11, 2025, Not Flagged";
        } 
        else if (userStory.contains("Access private feedback")) {
            return "STUDENT FEEDBACK:\n\n" +
                   "1. CS101 - Student123 → Prof_Java: ★★★☆☆\n" +
                   "   \"The instructor was helpful but lectures were too fast.\"\n" +
                   "   Submitted: April 1, 2025\n\n" +
                   "2. CS101 - Student456 → Prof_Java: ★★★★★\n" +
                   "   \"Great course, learned a lot! Assignments were challenging but fair.\"\n" +
                   "   Submitted: April 3, 2025\n\n" +
                   "3. MATH202 - Student789 → Prof_Calculus: ★★☆☆☆\n" +
                   "   \"Difficult to follow, need more examples and better explanations.\"\n" +
                   "   Submitted: April 6, 2025\n\n" +
                   "4. PHYS101 - Student123 → Prof_Physics: ★★★★★\n" +
                   "   \"Excellent teaching style, very engaging and clear explanations.\"\n" +
                   "   Submitted: April 8, 2025\n\n" +
                   "5. ENG201 - Student456 → Prof_Lit: ★★☆☆☆\n" +
                   "   \"The grading seems arbitrary and feedback on essays is minimal.\"\n" +
                   "   Submitted: April 10, 2025";
        }
        else if (userStory.contains("View interaction histories")) {
            return "STUDENT-INSTRUCTOR INTERACTIONS:\n\n" +
                   "1. Student123 → Prof_Java: QUESTION\n" +
                   "   \"How do I compile Java code?\"\n" +
                   "   April 6, 2025\n\n" +
                   "2. Prof_Java → Student123: ANSWER\n" +
                   "   \"Use javac command to compile Java code.\"\n" +
                   "   April 7, 2025\n\n" +
                   "3. Student123 → Prof_Java: OFFICE_HOURS\n" +
                   "   \"Discussed project difficulties\"\n" +
                   "   April 9, 2025\n\n" +
                   "4. Student456 → Prof_Calculus: EMAIL\n" +
                   "   \"Request for extension on assignment 3\"\n" +
                   "   April 10, 2025\n\n" +
                   "5. Student789 → Prof_Lit: GRADE_DISPUTE\n" +
                   "   \"Disputing grade on midterm essay\"\n" +
                   "   April 11, 2025";
        }
        else if (userStory.contains("Send private notifications")) {
            return "INSTRUCTOR NOTIFICATIONS:\n\n" +
                   "1. To: Prof_Java\n" +
                   "   \"Several students have reported difficulty with Assignment 4. Consider reviewing the instructions.\"\n" +
                   "   Sent: April 8, 2025, Unread\n\n" +
                   "2. To: Prof_Calculus\n" +
                   "   \"Your response time to student questions has exceeded 48 hours. Please try to respond more promptly.\"\n" +
                   "   Sent: April 9, 2025, Read\n\n" +
                   "3. To: Prof_Physics\n" +
                   "   \"Excellent student feedback on your recent lab session. Keep up the good work!\"\n" +
                   "   Sent: April 10, 2025, Unread\n\n" +
                   "4. To: Prof_Lit\n" +
                   "   \"Multiple students have requested more detailed feedback on their essays.\"\n" +
                   "   Sent: April 10, 2025, Unread\n\n" +
                   "5. To: Prof_Java\n" +
                   "   \"A concerning pattern of late submissions has been detected in your CS101 course.\"\n" +
                   "   Sent: April 11, 2025, Unread";
        }
        else if (userStory.contains("Set up customizable alerts")) {
            return "CONFIGURED ALERTS:\n\n" +
                   "1. NEGATIVE_FEEDBACK - CS101\n" +
                   "   Condition: average_rating < 3.0\n\n" +
                   "2. UNANSWERED_QUESTION - All Courses\n" +
                   "   Condition: response_time > 48 hours\n\n" +
                   "3. STUDENT_DISENGAGEMENT - MATH202\n" +
                   "   Condition: login_gap > 7 days\n\n" +
                   "4. GRADE_DECLINE - PHYS101\n" +
                   "   Condition: grade_drop > 15%\n\n" +
                   "5. LATE_RESPONSE - All Instructors\n" +
                   "   Condition: average_response > 24 hours";
        }
        else {
            return "No sample data available for this user story.";
        }
    }
    
    private void showAllUserStories() {
        Stage dialog = new Stage();
        
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        
        Label titleLabel = new Label("Staff Role User Stories");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        
        // Create tabs for different user story categories
        createCategoryTab(tabPane, "Question & Answer Monitoring", getQAMonitoringStories());
        createCategoryTab(tabPane, "Feedback Analysis", getFeedbackAnalysisStories());
        createCategoryTab(tabPane, "User Interaction Assessment", getInteractionStories());
        createCategoryTab(tabPane, "Staff & Instructor Communication", getCommunicationStories());
        createCategoryTab(tabPane, "Early Intervention System", getInterventionStories());
        
        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> dialog.close());
        HBox buttonBox = new HBox(closeButton);
        buttonBox.setAlignment(Pos.CENTER);
        
        layout.getChildren().addAll(titleLabel, tabPane, buttonBox);
        
        Scene dialogScene = new Scene(layout, 700, 600);
        dialog.setScene(dialogScene);
        dialog.setTitle("All Staff User Stories");
        dialog.show();
    }
    
    private void createCategoryTab(TabPane tabPane, String category, String[] stories) {
        Tab tab = new Tab(category);
        VBox tabContent = new VBox(15);
        tabContent.setPadding(new Insets(15));
        
        for (int i = 0; i < stories.length; i++) {
            Label storyLabel = new Label((i+1) + ". " + stories[i]);
            storyLabel.setWrapText(true);
            tabContent.getChildren().add(storyLabel);
        }
        
        ScrollPane scrollPane = new ScrollPane(tabContent);
        scrollPane.setFitToWidth(true);
        tab.setContent(scrollPane);
        tabPane.getTabs().add(tab);
    }
    
    // User story arrays by category
    private String[] getQAMonitoringStories() {
        return new String[] {
            "View all questions submitted by students across multiple courses so I can monitor the overall quality of student inquiries.",
            "Access all answers provided by instructors and teaching assistants so I can assess the quality and consistency of support.",
            "Filter questions and answers by course, date range, and topic so I can focus my review on specific areas.",
            "Flag inappropriate or concerning questions for further review so potential issues can be addressed promptly.",
            "Track response times to student questions so I can identify courses where students might not be receiving timely support."
        };
    }
    
    private String[] getFeedbackAnalysisStories() {
        return new String[] {
            "Access private feedback given by students about courses and instructors so I can identify patterns of concerns.",
            "Generate reports on feedback themes across different courses so administrators can understand systemic issues.",
            "Compare feedback between different course sections taught by the same instructor so I can identify instructor-specific patterns.",
            "Track feedback trends over time so I can determine if interventions are improving student satisfaction.",
            "Filter feedback by sentiment (positive/negative) so I can quickly identify areas needing immediate attention."
        };
    }
    
    private String[] getInteractionStories() {
        return new String[] {
            "View interaction histories between specific students and instructors so I can understand the context of any reported issues.",
            "Analyze participation metrics across different student demographics so I can identify potential equity gaps.",
            "Identify students who have stopped engaging with the platform so appropriate outreach can be initiated.",
            "Monitor discussion forum tone and content so I can flag concerning interactions between users.",
            "Track patterns of late submissions or assessment failures so I can help identify students who might need additional support."
        };
    }
    
    private String[] getCommunicationStories() {
        return new String[] {
            "Send private notifications to instructors about potential issues in their courses so they can address them proactively.",
            "Schedule check-in meetings with instructors whose courses show concerning patterns so we can develop improvement strategies.",
            "Share anonymized best practices from successful courses so other instructors can improve their teaching approaches.",
            "Collaborate with other staff members on addressing complex cases so we can provide consistent support.",
            "Document intervention strategies and outcomes so the team can build an evidence base for effective approaches."
        };
    }
    
    private String[] getInterventionStories() {
        return new String[] {
            "Set up customizable alerts for potential red flags so I can be notified automatically.",
            "Create and assign follow-up tasks to appropriate team members so issues don't fall through the cracks.",
            "Track the status of interventions so I can ensure all identified issues receive proper resolution.",
            "Access a dashboard showing potential issues ranked by severity so I can prioritize my efforts effectively.",
            "Document the resolution process for each intervention so we can improve our response protocols over time."
        };
    }
}